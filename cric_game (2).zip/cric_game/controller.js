var app= angular.module('mainApp',['ngRoute','ngStorage']);
app.config(function($routeProvider){
	$routeProvider
	.when('/',{
		templateUrl: 'login.html',
		controller: 'loginCtrl'
	})
	.when('/registration',{
		templateUrl: 'registration.html',
		controller: 'registerCtrl'
	})
	.when('/game',{
		templateUrl: 'game.html',
		controller: 'gameCtrl'
	})
	.otherwise({
		redirectTo:'/'
	});

});
app.controller('loginCtrl', function($scope, $location, $localStorage){
		console.log("hi from login");
		$scope.submit= function(){
			var uname= $scope.username;
			var password= $scope.password;
			if($scope.username==$localStorage.prevPageData.email&& $scope.password==$localStorage.prevPageData.password){
				alert("matched");
				$scope.username="";
				$scope.password="";
				$location.path('/game');
			}
				else{
			alert("Please enter correct username and Password")
		}
		};

		$scope.register= function(){
				$location.path('/registration');
		};
});
	app.controller('registerCtrl', function($scope, $location, $localStorage){
		console.log("hi from register");
		  $scope.pageData = {};
		$scope.signUp= function(){
			 $localStorage.prevPageData = $scope.pageData; 
			console.log($localStorage.prevPageData );
			$location.path('/login.html');
		};
});
	app.controller('gameCtrl', function($scope, $location, $localStorage, $http){
			console.log($localStorage.prevPageData.name);
			$scope.myname=$localStorage.prevPageData.name;
			$scope.date = (new Date()).toLocaleDateString('en-US');;
			console.log($scope.date);
		 	var url = "data.json";
			//console.log(url);
			$http.get(url).then( function(response) {
            $scope.matches = response.data.matches;
            //console.log(response);
            $scope.change='data';
            $scope.rad = {};
           	$scope.getVal=function(){
				//console.log($scope.rad);
        		$scope.change=$scope.rad;
        		$localStorage.newData = $scope.rad; 
				//console.log($localStorage.newData );
     		 }
            });
            var url1 = "participants.json";
			//console.log(url1);
			$http.get(url1).then( function(res) {
            $scope.participant = res.data.participant;
            console.log("participant",res);
            });

		});

